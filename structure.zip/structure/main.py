import structure

def main():
    print(structure.flags)

if __name__ == '__main__':
    main()